// this is the index-module1-fetch-vehicles-data.js

// FETCH VEHICLE DATA AND POPULATE THE VEHICLE SELECT ELEMENT
function fetchVehicleData() {
    // GET THE VEHICLE SELECT ELEMENT BY ID
    const selectVehicleElement = document.getElementById('select-vehicle-id');
    // CLEAR EXISTING OPTIONS IN THE SELECT ELEMENT
    selectVehicleElement.innerHTML = '';

    // SET PLACEHOLDER FOR THE SELECT ELEMENT
    selectVehicleElement.setAttribute('data-placeholder', 'Select an option');
    selectVehicleElement.classList.add('placeholder');

    // FETCH VEHICLE DATA FROM THE SERVER.js
    fetch('http://192.168.16.242:80/get_all_vehicles_from_vehicles_data_cars_list')
        .then(response => response.json())
        .then(data => {
            // IF DATA EXISTS AND IS NOT EMPTY
            if (data && data.length > 0) {
                // FILTER VEHICLE DATA BASED ON VEHICLE STATUS
                const filteredDataPedidos = data.filter(vehicleData => vehicleData.vehicle_status === 0);

                // CHECK IF THERE ARE ANY VEHICLES WITH STATUS 0
                if (filteredDataPedidos.length === 0) {
                    handleNoVehiclesAvailable(selectVehicleElement);  // ADD THIS LINE
                } else {
                    // FOR EACH FILTERED VEHICLE DATA, CREATE AND APPEND AN OPTION ELEMENT
                    filteredDataPedidos.forEach(vehicleData => {
                        const option = document.createElement('option');
                        option.textContent = vehicleData.vehicle_name;
                        option.value = vehicleData.vehicles_id;
                        selectVehicleElement.appendChild(option);
                    });

                    // ADD CHANGE EVENT LISTENER TO THE SELECT ELEMENT
                    selectVehicleElement.addEventListener('change', function () {
                        // SAVE SELECTED VEHICLE ID TO LOCAL STORAGE
                        localStorage.setItem('select-vehicle-id', selectVehicleElement.value);
                        // REMOVE PLACEHOLDER CLASS
                        selectVehicleElement.classList.remove('placeholder');
                    });
                }
            } else {
                handleNoVehiclesAvailable(selectVehicleElement);  // ADD THIS LINE
            }
        })
        // CATCH AND LOG ANY ERRORS DURING FETCHING
        .catch(error => {
            console.error('ERROR FETCHING VEHICLES:', error);
            handleNoVehiclesAvailable(selectVehicleElement);  // ADD THIS LINE
        });
}

// ADD THIS FUNCTION
function handleNoVehiclesAvailable(selectVehicleElement) {
    selectVehicleElement.innerHTML = '';
    const noVehiclesOption = document.createElement('option');
    noVehiclesOption.textContent = 'No vehicles available';
    noVehiclesOption.style.color = 'red';
    noVehiclesOption.disabled = true;
    noVehiclesOption.selected = true;
    selectVehicleElement.appendChild(noVehiclesOption);
}

export default fetchVehicleData;
