//* INPORT INDEX MODULE1 fetchVehicleData()
import fetchVehicleData from './index-module1-fetch-vehicles-data.js';

//* WAIT FOR THE DOM TO BE FULLY LOADED BEFORE EXECUTING THE FUNCTION
document.addEventListener('DOMContentLoaded', function () {

    // GET TODAY'S DATE
    const today = new Date();
    // FORMAT TODAY'S DATE
    const formattedToday = formatDate(today);

    // GET THE 'FROM DATE' INPUT ELEMENT BY ID
    const fromDateInput = document.getElementById('date-selection-input-id');
    // SET THE MINIMUM ATTRIBUTE OF THE 'FROM DATE' INPUT ELEMENT TO TODAY'S DATE
    fromDateInput.setAttribute('min', formattedToday);
    // SET THE VALUE OF THE 'FROM DATE' INPUT ELEMENT TO TODAY'S DATE
    fromDateInput.value = formattedToday;

    // GET THE 'TO DATE' INPUT ELEMENT BY ID
    const toDateInput = document.getElementById('date-selection-input-last-id');
    // SET THE MINIMUM ATTRIBUTE OF THE 'TO DATE' INPUT ELEMENT TO TODAY'S DATE
    toDateInput.setAttribute('min', formattedToday);
    // SET THE VALUE OF THE 'TO DATE' INPUT ELEMENT TO TODAY'S DATE
    toDateInput.value = formattedToday;

    // ARRAY OF INPUT ELEMENT IDS TO SAVE TO LOCAL STORAGE AND ADD FOCUS EVENT LISTENERS
    ['name-input-id', 'reason-input-id', 'date-selection-input-id', 'date-selection-input-last-id', 'select-vehicle-id'].forEach(id => {
        // SAVE INPUT ELEMENT VALUE TO LOCAL STORAGE
        saveToLocalStorage(id);
        // ADD FOCUS EVENT LISTENERS TO INPUT ELEMENTS
        addFocusEventListeners(id);
    });

    //& FETCH VEHICLE DATA AND POPULATE THE VEHICLE SELECT ELEMENT
    fetchVehicleData();

    //& GET THE SAVE BUTTON ELEMENT BY CLASS
    const saveButton = document.querySelector('.salva-pedidos-btn-cls');
    // ADD CLICK EVENT LISTENER TO THE SAVE BUTTON
    saveButton.addEventListener('click', function (event) {
        // PREVENT THE DEFAULT FORM SUBMISSION BEHAVIOR
        event.preventDefault();
        // SEND DATA TO THE SERVER
        sendDataToServer();
    });
});

//* FUNCTION TO FORMAT A DATE OBJECT AS 'YYYY-MM-DD'
function formatDate(date) {
    //& CREATE A NEW DATE OBJECT FROM THE GIVEN DATE
    const d = new Date(date);
    //& GET THE MONTH AND PAD WITH LEADING ZERO IF NECESSARY
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    //& GET THE DAY AND PAD WITH LEADING ZERO IF NECESSARY
    const day = d.getDate().toString().padStart(2, '0');
    //& GET THE FULL YEAR
    const year = d.getFullYear();
    //& RETURN THE FORMATTED DATE STRING
    return `${year}-${month}-${day}`;
}

//* SAVE INPUT ELEMENTS VALUE TO LOCAL STORAGE
function saveToLocalStorage(id) {
    const element = document.getElementById(id); //& GET THE ENTERED/INPUT ELEMENT BY ID
    element.addEventListener('change', function () {  //& ADD CHANGE EVENT LISTENER TO THE INPUT ELEMENT
        localStorage.setItem(id, element.value); //! SAVE THE ELEMENT VALUE TO LOCAL STORAGE
    });
}
        
//* ADD FOCUS EVENT LISTENERS TO INPUT ELEMENTS
function addFocusEventListeners(id) {
    const element = document.getElementById(id);
    if (element) {  //& IF THE ELEMENT EXISTS
        element.addEventListener('focus', function () { //! ADD FOCUS EVENT LISTENER TO THE ELEMENT
            // RESET ELEMENT STYLE AND PLACEHOLDER
            element.style.color = '';
            element.setAttribute('placeholder', '');
            // REMOVE ERROR MESSAGE IF PRESENT
            const errorMessage = document.getElementById(`${id}-error`);
            if (errorMessage) {
                errorMessage.remove();
            }
        });

        //& ADD INPUT EVENT LISTENER TO THE ELEMENT
        element.addEventListener('input', function () {
            //! UPDATE SAVE BUTTON TEXT
            const saveButton = document.querySelector('.salva-pedidos-btn-cls'); 
            saveButton.textContent = 'Guardar';
            //! RESET ELEMENT STYLE AND PLACEHOLDER
            element.style.color = '';
            element.setAttribute('placeholder', '');
            //! REMOVE ERROR MESSAGE IF PRESENT
            const errorMessage = document.getElementById(`${id}-error`); //? dynamically generates the ID 
            if (errorMessage) {
                errorMessage.remove();
            }
        });
    }
}

//* FUNCTION TO SEND DATA TO THE SERVER GIVEN BY AI
function sendDataToServer() {
    // GET INPUT VALUES BY ID
    const name = document.getElementById('name-input-id').value;
    const fromDate = document.getElementById('date-selection-input-id').value;
    const toDate = document.getElementById('date-selection-input-last-id').value;
    const reason = document.getElementById('reason-input-id').value;
    const selectedVehicle = document.getElementById('select-vehicle-id').value;

    // GET THE SELECTED VEHICLE NAME
    const vehicleName = document.querySelector('#select-vehicle-id option:checked').textContent;

    // CREATE DATA OBJECT TO BE SENT TO THE SERVER
    const data = {
        vehicles_id: selectedVehicle,
        user_name: name,
        vehicle_name: vehicleName,
        reason_for_needing_the_vehicle: reason,
        initial_date: fromDate,
        return_date: toDate,
        vehicle_status: 0
    };

    // MAP FOR INPUT ELEMENT IDS
    const idMap = {
        vehicles_id: 'select-vehicle-id',
        user_name: 'name-input-id',
        reason_for_needing_the_vehicle: 'reason-input-id',
        initial_date: 'date-selection-input-id',
        return_date: 'date-selection-input-last-id',
    };

    let isEmpty = false;
    // GET THE SAVE BUTTON ELEMENT BY CLASS
    const saveButton = document.querySelector('.salva-pedidos-btn-cls');

    //& CHECK IF ANY FIELD IS EMPTY
    for (const key in idMap) {
        const elementId = idMap[key];
        const element = document.getElementById(elementId);
        if (!data[key] || data[key] === '') {
            console.log(`Por favor llena la casilla ${elementId}`);
            saveButton.textContent = 'Llena todas las entradas para guardar';

            if (element) {
                element.style.color = 'red';
                element.setAttribute('placeholder', 'Falta este elemento');

                let errorMessage = document.getElementById(`${elementId}-error`);
                if (!errorMessage) {
                    errorMessage = document.createElement('div');
                    errorMessage.id = `${elementId}-error`;
                    errorMessage.textContent = 'Falta este elemento';
                    errorMessage.style.color = 'red';
                    element.parentNode.insertBefore(errorMessage, element);
                }

                element.classList.add('red-placeholder');
            }

            isEmpty = true;
        } else {
            if (element) {
                element.style.color = '';
                element.setAttribute('placeholder', '');
                const errorMessage = document.getElementById(`${elementId}-error`);
                if (errorMessage) {
                    errorMessage.remove();
                }
                element.classList.remove('red-placeholder');
            }
        }
    }

    //& IF ANY FIELD IS EMPTY, RETURN AND DO NOT SEND DATA
    if (isEmpty) {
        return;
    }

    console.log('All fields are filled, sending data to server:', data);

    //& RESET SAVE BUTTON TEXT
    saveButton.textContent = 'Guardar';

    //& SEND DATA TO THE SERVER
    postDataToServer(data)
        .then(handleSuccessResponse)
        .catch(handleErrorResponse);
}

//* POST DATA TO SERVER    
function postDataToServer(data) {
    return fetch('/post_client_data_into_server', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    });
}

// FUNCTION TO HANDLE SUCCESS RESPONSE AND UI UPDATES
function handleSuccessResponse(serverResponse) {
    console.log('Server response:', serverResponse);
    // CLEAR LOCAL STORAGE AFTER SUCCESSFUL RESPONSE
    localStorage.clear();

    // SHOW SUCCESS MESSAGE
    const SUCCESS_MESSAGE = document.createElement('div');
    SUCCESS_MESSAGE.textContent = 'GUARDADO EXITOSAMENTE';
    SUCCESS_MESSAGE.classList.add('success-message-cls');
    document.body.appendChild(SUCCESS_MESSAGE);

    // REMOVE SUCCESS MESSAGE AND RELOAD PAGE AFTER 4 SECONDS
    setTimeout(() => {
        SUCCESS_MESSAGE.remove();
        location.reload();
    }, 2000); // 3000ms for display + 1000ms extra
}

//* FUNCTION TO HANDLE ERROR RESPONSE
//! FIND OUT MORE ABOUT THIS
function handleErrorResponse(error) {
    console.error('ERROR:', error);
}
