// admin.js
import { toggleSearchBar, filterData } from './admin-search-module.js';



let generalData = [];
let entregasData = [];
let allData = [];
let vehicleData = [];

window.allData = allData; 
window.toggleSearchBar = () => toggleSearchBar(allData);
window.filterData = () => filterData(allData);


function fetchVehicleData() {
    return fetch('http://192.168.16.242:80/get_vehicle_data')
        .then(response => response.json())
        .then(data => {
            vehicleData = data;
        })
        .catch(error => console.error('Error fetching vehicle data:', error.message));
}

function fetchGeneralData() {
    return fetch('http://192.168.16.242:80/get_data_from_general_data_table_for_admin')
        .then(response => {
            if (!response.ok) {
                return response.json().then(error => {
                    throw new Error(`Server error: ${error.details}`);
                });
            }
            return response.json();
        })
        .then(data => {
            generalData = data;
            console.log('General Data fetched:', generalData); 
        })
        .catch(error => console.error('Error fetching general data:', error.message));
}

function fetchEntregasLogData() {
    return fetch('http://192.168.16.242:80/get_entregas_log_data')
        .then(response => {
            if (!response.ok) {
                return response.json().then(error => {
                    throw new Error(`Server error: ${error.details}`);
                });
            }
            return response.json();
        })
        .then(data => {
            entregasData = data;
            console.log('Entregas Log Data fetched:', entregasData); 
        })
        .catch(error => console.error('Error fetching entregas log data:', error.message));
}

function combineDataAndPopulateTable() {
    allData = [...generalData, ...entregasData];
    populateTable(allData);
}

function fetchDataAndPopulateTable() {
    Promise.all([fetchGeneralData(), fetchEntregasLogData(), fetchVehicleData()])
        .then(combineDataAndPopulateTable)
        .catch(error => console.error('Error combining data:', error));
}

function populateTable(data) {
    console.log('Populating table with data:', data);
    const bookingData = document.getElementById('booking-data');
    bookingData.innerHTML = ''; 

    // Sort the data by submission_time before populating the table
    data.sort((a, b) => new Date(a.submission_time) - new Date(b.submission_time));

    for (let i = 0; i < data.length && i < 30; i++) {
        const row = document.createElement('tr');

        if (data[i]) {
            const item = data[i];
            const entryType = item.hasOwnProperty('id_log') ? 'entrega' : 'pedido';
            row.classList.add(entryType === 'entrega' ? 'entregas-row' : 'pedidos-row');

            // Find current_kilometers for the vehicle
            const vehicle = vehicleData.find(v => v.vehicle_name === item.vehicle_name);
            const currentKilometers = vehicle ? vehicle.current_kilometers : 'N/A';

            // Your existing columns and calculations
            const submissionTime = item.submission_time ? formatTime(item.submission_time) : 'N/A';
            const userName = entryType === 'entrega' ? item.entregas_name || 'N/A' : item.user_name || 'N/A';
            const vehicleName = item.vehicle_name || 'N/A';
            const reason = entryType === 'pedido' ? item.reason_for_needing_the_vehicle || 'N/A' : item.reason || 'N/A';
            const initialDate = item.initial_date ? formatDate(item.initial_date) : 'N/A';
            const returnDate = item.return_date ? formatDate(item.return_date) : 'N/A';
            const initialKilometers = item.initial_kilometers || 0;

            // Calculate total kilometers for 'entrega' rows
            const totalKilometers = entryType === 'entrega' 
                ? currentKilometers - initialKilometers 
                : 'N/A';

            // Updated row.innerHTML with your existing structure
            row.innerHTML = `
                <td>${entryType}</td>
                <td>${submissionTime}</td>
                <td>${userName}</td>
                <td>${vehicleName}</td>
                <td>${reason}</td>
                <td>${initialDate}</td>
                <td>${returnDate}</td>
                <td>${initialKilometers}</td>
                <td>${currentKilometers}</td> <!-- Now includes fetched current kilometers -->
                <td>${totalKilometers}</td>
            `;
        } else {
            row.innerHTML = '<td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td>';
        }
        bookingData.appendChild(row);
    }
}

export { populateTable };

function formatDate(dateString) {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}


function formatTime(dateString) {
    const date = new Date(dateString);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}

window.onload = fetchDataAndPopulateTable;

window.toggleSearchBar = () => toggleSearchBar(allData);