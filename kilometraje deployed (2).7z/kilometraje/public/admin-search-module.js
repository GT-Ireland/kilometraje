
// admin-search-module.js

import { populateTable } from './admin.js';

function toggleSearchBar(allData) {
    var searchType = document.getElementById('search-type').value;
    var dropdownOptions = document.getElementById('dropdown-options');
    dropdownOptions.innerHTML = "";

    if (searchType) {
        var uniqueValues = [...new Set(allData.map(item => {
            let value;
            if (searchType === 'user_name') {
                value = item.hasOwnProperty('id_log') ? item.entregas_name : item.user_name;
            } else {
                value = item[searchType];
            }

            // Format dates if the searchType is for a date field
            if (value && (searchType === 'initial_date' || searchType === 'return_date')) {
                value = formatDate(value);
            }

            return value;
        }).filter(value => value))];

        uniqueValues.forEach(value => {
            var listItem = document.createElement('li');
            listItem.textContent = value;
            listItem.style.cursor = 'pointer';
            listItem.style.fontSize = 'inherit';
            listItem.onclick = function() {
                filterData(allData, value, searchType); // Trigger the filter when an option is clicked
            };
            dropdownOptions.appendChild(listItem);
        });

        dropdownOptions.style.display = "block";

        // Add an event listener to the document to close the dropdown when clicking outside of it
        document.addEventListener('click', function handleClickOutside(event) {
            if (!dropdownOptions.contains(event.target) && event.target.id !== 'search-type') {
                dropdownOptions.style.display = "none";
                document.removeEventListener('click', handleClickOutside);
            }
        });
    } else {
        dropdownOptions.style.display = "none";
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

function filterData(allData, selectedValue, searchType) {
    if (searchType && selectedValue) {
        var filteredData = allData.filter(item => {
            if (searchType === 'user_name') {
                return item.hasOwnProperty('id_log') 
                    ? item.entregas_name === selectedValue 
                    : item.user_name === selectedValue;
            }
            return item[searchType] === selectedValue;
        });
        populateTable(filteredData); // Display the matching rows
    }
}

export { toggleSearchBar, filterData };






