var currentKilometers; //& STORE THE CURRENT KILOMETERS OF THE SELECTED VEHICLE

//*FETCH FROM SERVER.JS
function fetchVehicleData() {
    const SELECT_VEHICLES_FROM_ENTREGAS_HTML = document.getElementById('entregas-select-vehicle-id'); //& GET THE SELECT ELEMENT FOR VEHICLES
    console.log('STARTING VEHICLES FETCH');
    //^ FETCH VEHICLE DATA FROM SERVER.js
    fetch('http://192.168.16.242:80/get_all_vehicles_from_vehicles_data_cars_list')
        .then(response => {
            console.log('RECEIVED RESPONSE FROM SERVER');
            return response.json();
        })
        .then(data => {
            console.log('FETCHED VEHICLES FROM DB THROUGH ENTREGAS SERVER:', data);
            //! IF THERE'S DATA IN THE HTML ELEMENT CLEAR IT WITH THE LINE BELOW
            if (SELECT_VEHICLES_FROM_ENTREGAS_HTML) {
                //! CLEAR EXISTING OPTIONS
                SELECT_VEHICLES_FROM_ENTREGAS_HTML.innerHTML = '';
                //! ADD DEFAULT OPTION
                let defaultOption = document.createElement('option');
                defaultOption.textContent = 'Selecione un vehiculo';
                defaultOption.value = '';
                SELECT_VEHICLES_FROM_ENTREGAS_HTML.appendChild(defaultOption);

                //^ FILTER VEHICLES WITH STATUS 1
                const filteredDataEntregas = data.filter(vehicleData => vehicleData.vehicle_status === 1);
                console.log('Filtered Data:', filteredDataEntregas); //& Display filtered data

                if (filteredDataEntregas.length === 0) {
                    console.log('No hay vehículos con estado 1'); //& Log no vehicles with status 1
                } else {
                    //! ADD FILTERED VEHICLES TO SELECT ELEMENT
                    filteredDataEntregas.forEach(vehicleData => {
                        const option = document.createElement('option');
                        option.textContent = vehicleData.vehicle_name;
                        option.value = vehicleData.vehicles_id;
                        SELECT_VEHICLES_FROM_ENTREGAS_HTML.appendChild(option);
                    });
                }
                //^ STORE FILTERED DATA IN LOCAL STORAGE
                try {
                    localStorage.setItem('filteredDataEntregas', JSON.stringify(filteredDataEntregas));
                    console.log('Data stored in localStorage successfully'); //& Confirm successful storage
                } catch (e) {
                    console.error('Error storing data in localStorage:', e); //& Log storage error
                }
            }
        })
        .catch(error => {
            console.error('ERROR FETCHING VEHICLE DATA: YOUR SERVER MAY BE NOT RUNNING', error); //& Log fetch error
        });
}

//* CHECK IF BOTH FIELDS HAVE 6 DIGITS BEFORE ENABLING THE SALVAR BTN
function updateSaveButtonState() {
    var initialKilometers = document.getElementById('input-kilometrage-inicial-id').value;
    var finalKilometers = document.getElementById('input-kilometer-digit-limitation-id').value;
    var saveButton = document.querySelector('.entregas-btn-save-cls');

    if (initialKilometers.length === 6 && finalKilometers.length === 6) {
        saveButton.disabled = false;
        saveButton.classList.remove('blocked-on-hover');  // REMOVE BLOCKED ON HOVER CLASS
    } else {
        saveButton.disabled = true;
        saveButton.classList.add('blocked-on-hover');  // ADD BLOCKED ON HOVER CLASS
    }
}

//* ENSURE LIMIT IN DIGITS IN LENGTH AND ENABLES AND DISABLES THE SAVE BUTTON
function checkKilometersValue(kilometerInput) {
    var userKilometers = kilometerInput.value.slice(0, 6); // LIMIT INPUT TO 6 DIGITS
    kilometerInput.value = userKilometers;  // UPDATE INPUT VALUE
    updateSaveButtonState();  // UPDATE BUTTON STATE BASED ON INPUT

    if (userKilometers.length < 6) {  // IF THE INPUT LENGTH IS LESS THAN 6, DISABLE BUTTON
        document.querySelector('.entregas-btn-save-cls').disabled = true;
        return;  // RETURN EARLY
    }

    //^ VALIDATE AND COMPARE KILOMETERS FOR BOTH INPUTS
    var selectedVehicleId = document.getElementById('entregas-select-vehicle-id').value;  //^ GET THE SELECTED VEHICLE'S ID
    var selectedVehicle = JSON.parse(localStorage.getItem('filteredDataEntregas')).find(vehicle =>
        vehicle.vehicles_id.toString() === selectedVehicleId);  //& FIND SELECTED VEHICLE
    console.log('Selected Vehicle:', selectedVehicle);  //^ DISPLAY SELECTED VEHICLE
    currentKilometers = selectedVehicle ? selectedVehicle.current_kilometers : 0;  //& UPDATE CURRENT KILOMETERS BASED ON SELECTED VEHICLE
    var currentKilometersLastSixDigits = currentKilometers % 1000000;  //& GET THE LAST SIX DIGITS OF CURRENT KILOMETERS
    var newKilometersLastSixDigits = parseInt(userKilometers) % 1000000;  //& GET THE LAST SIX DIGITS OF THE NEW KILOMETERS INPUT BY THE USER
    var kilometersDifference = newKilometersLastSixDigits - currentKilometersLastSixDigits;  //& CALCULATE THE DIFFERENCE BETWEEN NEW AND CURRENT KILOMETERS

    if (kilometerInput.id === 'input-kilometrage-inicial-id') {
        // Validation for initial kilometers input (allows equal to current kilometers)
        if (newKilometersLastSixDigits < currentKilometersLastSixDigits) {
            alert('El número no puede ser menor que los kilómetros actuales del vehículo');  //& SHOW ALERT IF NEW KILOMETERS IS LESS THAN CURRENT
            document.querySelector('.entregas-btn-save-cls').disabled = true;  //& DISABLE SAVE BUTTON
            kilometerInput.value = currentKilometersLastSixDigits;  // REPLACE THE INPUT VALUE WITH THE CURRENT KILOMETERS
            kilometerInput.focus();  //& FOCUS ON INPUT FIELD
        } else if (kilometersDifference > 100) {
            var confirmKilometerWarning = confirm('¿Seguro añadió más de ' + kilometersDifference + ' kilómetros en su último viaje?');  //& SHOW CONFIRMATION DIALOG IF KILOMETER DIFFERENCE IS SIGNIFICANT
            if (confirmKilometerWarning) {
                document.querySelector('.entregas-btn-save-cls').disabled = false;  //& ENABLE SAVE BUTTON IF CONFIRMED
                document.querySelector('.entregas-btn-save-cls').focus();  //& FOCUS ON SAVE BUTTON
            } else {
                kilometerInput.value = currentKilometersLastSixDigits;  // REPLACE THE INPUT VALUE WITH THE CURRENT KILOMETERS
                kilometerInput.focus();  //& FOCUS BACK ON INPUT FIELD IF CANCELED
            }
        }
    } else if (kilometerInput.id === 'input-kilometer-digit-limitation-id') {
        // Validation for final kilometers input (cannot be less than or equal to current kilometers)
        if (newKilometersLastSixDigits <= currentKilometersLastSixDigits) {
            alert('El número no puede ser menor o igual a los kilómetros actuales del vehículo');  //& SHOW ALERT IF NEW KILOMETERS IS LESS THAN OR EQUAL TO CURRENT
            document.querySelector('.entregas-btn-save-cls').disabled = true;  //& DISABLE SAVE BUTTON
            kilometerInput.value = '';  // CLEAR THE INPUT FIELD
            kilometerInput.focus();  //& FOCUS ON INPUT FIELD
        }
    }

    updateSaveButtonState();  // Update save button state after processing
}

function updateSaveButtonState() {
    var initialKilometers = document.getElementById('input-kilometrage-inicial-id').value;
    var finalKilometers = document.getElementById('input-kilometer-digit-limitation-id').value;
    var saveButton = document.querySelector('.entregas-btn-save-cls');

    // Enable the button only if both inputs have valid 6-digit values and a vehicle is selected
    if (initialKilometers.length === 6 && finalKilometers.length === 6 &&
        parseInt(finalKilometers) > parseInt(initialKilometers) &&
        document.getElementById('entregas-select-vehicle-id').value) {
        saveButton.disabled = false;
        saveButton.classList.remove('blocked-on-hover');  // REMOVE BLOCKED ON HOVER CLASS
    } else {
        saveButton.disabled = true;
        saveButton.classList.add('blocked-on-hover');  // ADD BLOCKED ON HOVER CLASS
    }
}

function handleVehicleSelection() {
    var vehicleSelect = document.getElementById('entregas-select-vehicle-id');
    var initialKilometersInput = document.getElementById('input-kilometrage-inicial-id');
    var finalKilometersInput = document.getElementById('input-kilometer-digit-limitation-id');

    if (vehicleSelect.value) {  // IF A VEHICLE IS SELECTED
        initialKilometersInput.disabled = false;
        finalKilometersInput.disabled = false;
        initialKilometersInput.classList.remove('kilometers-inputs');  // REMOVE DISABLED CLASS
        finalKilometersInput.classList.remove('kilometers-inputs');  // REMOVE DISABLED CLASS
        initialKilometersInput.style.opacity = "1";
        finalKilometersInput.style.opacity = "1";
        initialKilometersInput.style.cursor = "auto";
        finalKilometersInput.style.cursor = "auto";
    } else {  // IF NO VEHICLE IS SELECTED
        initialKilometersInput.disabled = true;
        finalKilometersInput.disabled = true;
        initialKilometersInput.classList.add('kilometers-inputs');  // ADD DISABLED CLASS
        finalKilometersInput.classList.add('kilometers-inputs');  // ADD DISABLED CLASS
    }
}

//* INITIALIZE THE PAGE, FETCH DATA, AND SETUP BUTTON STATE
window.onload = function() {
    fetchVehicleData();
    document.getElementById('entregas-select-vehicle-id').addEventListener('change', handleVehicleSelection);
    document.querySelector('.entregas-btn-save-cls').disabled = true;  // DISABLE THE SAVE BUTTON ON PAGE LOAD
    document.querySelector('.entregas-btn-save-cls').classList.add('blocked-on-hover'); // ADD BLOCKED ON HOVER CLASS ON PAGE LOAD
    handleVehicleSelection();  // INITIALIZE THE INPUT STATES BASED ON VEHICLE SELECTION
    updateSaveButtonState();  // CHECK BUTTON STATE IMMEDIATELY AFTER LOAD
}


// Function to save the data to the server
function saveEntregasVehicleData() {
    var selectedVehicleId = document.getElementById('entregas-select-vehicle-id').value;
    var initialKilometers = parseInt(document.getElementById('input-kilometrage-inicial-id').value);
    var currentKilometers = parseInt(document.getElementById('input-kilometer-digit-limitation-id').value);
    var reason = document.getElementById('ID-ENTREGAS-INPUT-REASON-FOR-NEEDING-THE-VEHICLE').value;
    var entregasName = document.getElementById('ID-ENTREGAS-INPUT-NAME').value;
    var returnDate = new Date().toISOString().slice(0, 19).replace('T', ' ');

    // Validate that all required fields are filled
    if (!selectedVehicleId || !initialKilometers || !currentKilometers || !reason || !entregasName) {
        alert('Por favor complete todos los campos requeridos antes de guardar.');
        return;
    }

    // Prepare data to send to the server for vehicles_data_cars_list
    var dataToSend = {
        vehicles_id: selectedVehicleId,
        new_kilometers: currentKilometers, 
        initial_kilometers: initialKilometers,
        vehicle_status: 0 
    };
    console.log('Data to Send to vehicles_data_cars_list:', dataToSend);

    // Send the prepared data to the server to update vehicles_data_cars_list
    fetch('http://192.168.16.242/vehicles_data_cars_list', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dataToSend)
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => { throw new Error(text) });
        }
        console.log('Received response from server for vehicles_data_cars_list'); 
        return response.text();
    })
    .then(data => {
        console.log('Data saved in vehicles_data_cars_list:', data); 
    })
    .catch(error => {
        console.error('Error saving data in vehicles_data_cars_list:', error);
    });

    // Prepare data for entregas_log
    var logDataToSend = {
        vehicle_name: document.getElementById('entregas-select-vehicle-id').options[document.getElementById('entregas-select-vehicle-id').selectedIndex].text,
        initial_kilometers: initialKilometers,
        current_kilometers: currentKilometers,
        reason: reason,
        return_date: returnDate,
        entregas_name: entregasName
    };
    console.log('Data to Send to entregas_log:', logDataToSend);

    // Send the data to save in entregas_log, including the reason
    fetch('http://192.168.16.242/save_entregas_log', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(logDataToSend)
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => { throw new Error(text) });
        }
        return response.json();
    })
    .then(data => {
        console.log('Saved entregas log:', data);

        // Display success message and reload the page
        const SUCCESS_MESSAGE = document.createElement('div');
        SUCCESS_MESSAGE.textContent = 'GUARDADO EXITOSAMENTE';
        SUCCESS_MESSAGE.classList.add('success-message-cls');
        document.body.appendChild(SUCCESS_MESSAGE);
        setTimeout(() => {
            SUCCESS_MESSAGE.remove();
        }, 3000);
        document.querySelector('.entregas-btn-save-cls').classList.add('clicked');

        setTimeout(() => {
            location.reload();
        }, 1500);
    })
    .catch(error => {
        console.error('Error saving entregas log:', error.message);
    });
}


