// Check if the navigation is already present in the document
if (!document.querySelector('nav')) {
    //& Define the navigation HTML structure
    const navigationHTML = `
      <nav>
          <a href="/index.html" class="pedidos-page-a a-cls">Pedidos</a>
          <a href="/entregas.html" class="entregas-page-a a-cls">Entregas</a>
          <a href="/admin.html" class="admin-page-a a-cls">Admin</a>
      </nav>
    `;

    //& Insert the navigation into the page
    document.body.insertAdjacentHTML('afterbegin', navigationHTML);
}

//* Check if 'path' has already been declared to avoid redeclaration
if (typeof path === 'undefined') {
    //& NAVIGATION Get the current URL path TO BE ABLE TO MARK ACTIVE PAGE
    var path = window.location.pathname;
    if (path === '/') path = '/index.html';
    // console.log(window.location.pathname);
}

//* Check if 'navLinks' has already been declared to avoid redeclaration
if (typeof navLinks === 'undefined') {
    //& Get all navigation links
    var navLinks = document.querySelectorAll('nav a');
    
    //& Loop through each navigation link
    navLinks.forEach(link => {
        //! Get the href attribute of the link and normalize it
        const linkPath = link.getAttribute('href');
        // console.log('Link href:', linkPath);
        
        //! If the href attribute of the link matches the current path
        //! ENSURE THE LINKPATH IS CORRECT FOR COMPARISON HANDLE RELATIVE PATHS IF NECESSARY
        const fullLinkPath = new URL(linkPath, window.location.origin).pathname;
        const normalizedPath = path.replace(/\/$/, ''); //~ Remove trailing slash for consistency
        const normalizedLinkPath = fullLinkPath.replace(/\/$/, '');
        //! COMPARE HREF WITH THE CURRENT PATH
        if (normalizedLinkPath === normalizedPath) {
            //^ Add the 'active' class to the link
            link.classList.add('active');
        }
    });
}
